// Entrada para a Vercel (serverless)
module.exports = require('../src/app');
