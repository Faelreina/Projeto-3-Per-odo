const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => res.json({ status: 'API Polo Médico no ar' }));
app.use('/auth', require('./routes/auth'));
app.use('/medicos', require('./routes/medicos'));
app.use('/consultas', require('./routes/consultas'));

module.exports = app;
