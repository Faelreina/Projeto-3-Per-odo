const router = require('express').Router();
const db = require('../db');

// Listar (com filtro opcional por especialidade)
router.get('/', async (req, res) => {
  const { especialidade } = req.query;
  const [rows] = especialidade
    ? await db.execute('SELECT * FROM medicos WHERE especialidade = ?', [especialidade])
    : await db.execute('SELECT * FROM medicos');
  res.json(rows);
});

router.get('/:id', async (req, res) => {
  const [rows] = await db.execute('SELECT * FROM medicos WHERE id = ?', [req.params.id]);
  if (!rows[0]) return res.status(404).json({ erro: 'Médico não encontrado' });
  res.json(rows[0]);
});

router.post('/', async (req, res) => {
  const { nome, especialidade, crm } = req.body;
  const [r] = await db.execute(
    'INSERT INTO medicos (nome, especialidade, crm) VALUES (?, ?, ?)',
    [nome, especialidade, crm]
  );
  res.status(201).json({ id: r.insertId, nome, especialidade, crm });
});

module.exports = router;
