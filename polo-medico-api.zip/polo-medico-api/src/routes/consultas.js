const router = require('express').Router();
const db = require('../db');
const auth = require('../middlewares/auth');

router.use(auth); // tudo aqui exige login

router.get('/', async (req, res) => {
  const [rows] = await db.execute(
    `SELECT c.id, c.data_hora, c.status, m.nome AS medico, m.especialidade
     FROM consultas c JOIN medicos m ON m.id = c.medico_id
     WHERE c.usuario_id = ? ORDER BY c.data_hora`,
    [req.usuario.id]
  );
  res.json(rows);
});

router.post('/', async (req, res) => {
  const { medico_id, data_hora } = req.body;

  const [conflito] = await db.execute(
    `SELECT id FROM consultas
     WHERE medico_id = ? AND data_hora = ? AND status = 'agendada'`,
    [medico_id, data_hora]
  );
  if (conflito.length)
    return res.status(409).json({ erro: 'Horário indisponível' });

  const [r] = await db.execute(
    'INSERT INTO consultas (usuario_id, medico_id, data_hora) VALUES (?, ?, ?)',
    [req.usuario.id, medico_id, data_hora]
  );
  res.status(201).json({ id: r.insertId });
});

router.patch('/:id/cancelar', async (req, res) => {
  const [r] = await db.execute(
    `UPDATE consultas SET status = 'cancelada' WHERE id = ? AND usuario_id = ?`,
    [req.params.id, req.usuario.id]
  );
  if (!r.affectedRows) return res.status(404).json({ erro: 'Consulta não encontrada' });
  res.json({ ok: true });
});

module.exports = router;
