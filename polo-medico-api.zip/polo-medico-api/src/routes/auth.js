const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');

router.post('/registro', async (req, res) => {
  const { nome, email, senha } = req.body;
  if (!nome || !email || !senha)
    return res.status(400).json({ erro: 'Campos obrigatórios' });

  try {
    const hash = await bcrypt.hash(senha, 10);
    const [r] = await db.execute(
      'INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)',
      [nome, email, hash]
    );
    res.status(201).json({ id: r.insertId, nome, email });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY')
      return res.status(409).json({ erro: 'E-mail já cadastrado' });
    res.status(500).json({ erro: 'Erro interno' });
  }
});

router.post('/login', async (req, res) => {
  const { email, senha } = req.body;
  const [rows] = await db.execute('SELECT * FROM usuarios WHERE email = ?', [email]);
  const user = rows[0];

  if (!user || !(await bcrypt.compare(senha, user.senha_hash)))
    return res.status(401).json({ erro: 'Credenciais inválidas' });

  const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '2h' });
  res.json({ token });
});

module.exports = router;
