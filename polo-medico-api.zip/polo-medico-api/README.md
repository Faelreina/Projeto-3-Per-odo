# Polo Médico API

Back end (Node.js + Express + MySQL) para o site e o app mobile do Polo Médico.

## Estrutura
- `src/`: código da API (rotas, middleware de autenticação, conexão)
- `api/index.js`: entrada para o deploy na Vercel
- `database/`: scripts e docker do MySQL (separado da API)

## Rodar local
```bash
cp .env.example .env     # preencha os valores
npm install
npm run dev
```

## Rotas
| Método | Rota | Auth | Descrição |
|---|---|---|---|
| POST | /auth/registro | não | Cadastrar usuário |
| POST | /auth/login | não | Login (retorna JWT) |
| GET | /medicos | não | Listar (?especialidade=) |
| GET | /medicos/:id | não | Detalhe |
| POST | /medicos | não* | Cadastrar médico |
| GET | /consultas | sim | Minhas consultas |
| POST | /consultas | sim | Agendar |
| PATCH | /consultas/:id/cancelar | sim | Cancelar |

*Em produção, restringir a perfil admin.

## Deploy (Vercel)
`vercel` na raiz e cadastrar as variáveis do `.env` no painel. O MySQL precisa estar hospedado em outro serviço.
