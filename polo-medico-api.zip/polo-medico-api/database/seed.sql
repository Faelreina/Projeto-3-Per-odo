USE polo_medico;

INSERT INTO medicos (nome, especialidade, crm) VALUES
  ('Dra. Ana Souza', 'Cardiologia', 'CRM-PE 11111'),
  ('Dr. Carlos Lima', 'Clínica Geral', 'CRM-PE 22222'),
  ('Dra. Marina Alves', 'Pediatria', 'CRM-PE 33333');
