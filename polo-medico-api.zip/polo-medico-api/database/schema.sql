CREATE DATABASE IF NOT EXISTS polo_medico CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE polo_medico;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS medicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  especialidade VARCHAR(80) NOT NULL,
  crm VARCHAR(20) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS consultas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  medico_id INT NOT NULL,
  data_hora DATETIME NOT NULL,
  status ENUM('agendada','cancelada','realizada') DEFAULT 'agendada',
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  FOREIGN KEY (medico_id) REFERENCES medicos(id)
);
