# Banco de dados (MySQL)

Esta pasta é independente da API. O MySQL **não roda na Vercel**, então em produção
use um serviço externo (Railway, Aiven, Clever Cloud...) e rode os scripts lá.

- `schema.sql`: cria o banco e as tabelas
- `seed.sql`: dados de exemplo (médicos)
- `docker-compose.yml`: MySQL local para desenvolvimento

## Local com Docker
```bash
cd database
docker compose up -d
```
No `.env` da API: `DB_HOST=localhost`, `DB_USER=root`, `DB_PASS=root`, `DB_NAME=polo_medico`.

## Em um MySQL já existente
```bash
mysql -h HOST -u USUARIO -p < schema.sql
mysql -h HOST -u USUARIO -p < seed.sql
```
