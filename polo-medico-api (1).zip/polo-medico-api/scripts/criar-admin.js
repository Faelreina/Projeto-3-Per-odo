// Uso: npm run criar-admin -- "Nome" email@exemplo.com senha123
const bcrypt = require('bcryptjs');
const db = require('../src/db');

const [nome, email, senha] = process.argv.slice(2);

if (!nome || !email || !senha) {
  console.log('Uso: npm run criar-admin -- "Nome" email@exemplo.com senha123');
  process.exit(1);
}

(async () => {
  try {
    const hash = await bcrypt.hash(senha, 10);
    await db.execute(
      `INSERT INTO usuarios (nome, email, senha_hash, perfil)
       VALUES (?, ?, ?, 'admin')
       ON DUPLICATE KEY UPDATE perfil = 'admin'`,
      [nome, email.toLowerCase(), hash]
    );
    console.log('Admin criado (ou usuário existente promovido a admin).');
  } catch (e) {
    console.error('Erro:', e.message);
    process.exitCode = 1;
  } finally {
    await db.end();
  }
})();
