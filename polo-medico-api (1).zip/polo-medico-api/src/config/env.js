// Carrega o .env e confere se nada obrigatório está faltando.
// Se faltar algo, o erro aparece claro no terminal / log da Vercel.
require('dotenv').config();

const obrigatorias = ['DB_HOST', 'DB_USER', 'DB_NAME', 'JWT_SECRET'];
const faltando = obrigatorias.filter((chave) => !process.env[chave]);

if (faltando.length > 0) {
  throw new Error(`Variáveis de ambiente faltando: ${faltando.join(', ')}`);
}

module.exports = {
  DB_HOST: process.env.DB_HOST,
  DB_PORT: Number(process.env.DB_PORT) || 3306,
  DB_USER: process.env.DB_USER,
  DB_PASS: process.env.DB_PASS || '',
  DB_NAME: process.env.DB_NAME,
  DB_SSL: process.env.DB_SSL === 'true',
  JWT_SECRET: process.env.JWT_SECRET,
  PORT: Number(process.env.PORT) || 3000,
};
