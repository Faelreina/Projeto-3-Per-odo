const router = require('express').Router();
const db = require('../db');
const asyncHandler = require('../utils/asyncHandler');
const { HttpError } = require('../utils/httpError');
const { auth, apenasAdmin } = require('../middlewares/auth');
const v = require('../utils/validar');

// Público: listar (filtro opcional ?especialidade=Cardiologia)
router.get('/', asyncHandler(async (req, res) => {
  const { especialidade } = req.query;
  const [rows] =
    typeof especialidade === 'string' && especialidade.trim() !== ''
      ? await db.execute(
          'SELECT id, nome, especialidade, crm FROM medicos WHERE especialidade = ? ORDER BY nome',
          [especialidade.trim()]
        )
      : await db.execute('SELECT id, nome, especialidade, crm FROM medicos ORDER BY nome');
  res.json(rows);
}));

// Público: detalhe
router.get('/:id', asyncHandler(async (req, res) => {
  const id = v.id(req.params.id);
  const [rows] = await db.execute(
    'SELECT id, nome, especialidade, crm FROM medicos WHERE id = ?',
    [id]
  );
  if (!rows[0]) throw new HttpError(404, 'Médico não encontrado');
  res.json(rows[0]);
}));

function lerCorpo(body = {}) {
  return {
    nome: v.texto(body.nome, 'nome', { max: 100 }),
    especialidade: v.texto(body.especialidade, 'especialidade', { max: 80 }),
    crm: v.texto(body.crm, 'crm', { max: 20 }),
  };
}

// Só admin: criar
router.post('/', auth, apenasAdmin, asyncHandler(async (req, res) => {
  const { nome, especialidade, crm } = lerCorpo(req.body);
  try {
    const [r] = await db.execute(
      'INSERT INTO medicos (nome, especialidade, crm) VALUES (?, ?, ?)',
      [nome, especialidade, crm]
    );
    res.status(201).json({ id: r.insertId, nome, especialidade, crm });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'CRM já cadastrado');
    throw e;
  }
}));

// Só admin: atualizar
router.put('/:id', auth, apenasAdmin, asyncHandler(async (req, res) => {
  const id = v.id(req.params.id);
  const { nome, especialidade, crm } = lerCorpo(req.body);
  try {
    const [r] = await db.execute(
      'UPDATE medicos SET nome = ?, especialidade = ?, crm = ? WHERE id = ?',
      [nome, especialidade, crm, id]
    );
    if (!r.affectedRows) throw new HttpError(404, 'Médico não encontrado');
    res.json({ id, nome, especialidade, crm });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'CRM já cadastrado');
    throw e;
  }
}));

// Só admin: remover
router.delete('/:id', auth, apenasAdmin, asyncHandler(async (req, res) => {
  const id = v.id(req.params.id);
  try {
    const [r] = await db.execute('DELETE FROM medicos WHERE id = ?', [id]);
    if (!r.affectedRows) throw new HttpError(404, 'Médico não encontrado');
    res.status(204).end();
  } catch (e) {
    if (e.code === 'ER_ROW_IS_REFERENCED_2') {
      throw new HttpError(409, 'Médico possui consultas e não pode ser removido');
    }
    throw e;
  }
}));

module.exports = router;
