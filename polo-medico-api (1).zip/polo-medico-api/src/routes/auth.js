const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const env = require('../config/env');
const asyncHandler = require('../utils/asyncHandler');
const { HttpError } = require('../utils/httpError');
const v = require('../utils/validar');

router.post('/registro', asyncHandler(async (req, res) => {
  const body = req.body || {};
  const nome = v.texto(body.nome, 'nome', { max: 100 });
  const email = v.email(body.email);
  const senha = v.senha(body.senha);

  const hash = await bcrypt.hash(senha, 10);
  try {
    // o perfil sempre nasce como "paciente"; admin só pelo script criar-admin
    const [r] = await db.execute(
      'INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)',
      [nome, email, hash]
    );
    res.status(201).json({ id: r.insertId, nome, email });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'E-mail já cadastrado');
    throw e;
  }
}));

router.post('/login', asyncHandler(async (req, res) => {
  const body = req.body || {};
  const email = v.email(body.email);
  if (typeof body.senha !== 'string' || body.senha === '') {
    throw new HttpError(400, 'Campo "senha" é obrigatório');
  }

  const [rows] = await db.execute(
    'SELECT id, nome, email, senha_hash, perfil FROM usuarios WHERE email = ?',
    [email]
  );
  const usuario = rows[0];

  // mesma mensagem para e-mail errado e senha errada (não revela qual existe)
  if (!usuario || !(await bcrypt.compare(body.senha, usuario.senha_hash))) {
    throw new HttpError(401, 'E-mail ou senha incorretos');
  }

  const token = jwt.sign(
    { id: usuario.id, perfil: usuario.perfil },
    env.JWT_SECRET,
    { expiresIn: '2h' }
  );
  res.json({
    token,
    usuario: { id: usuario.id, nome: usuario.nome, email: usuario.email, perfil: usuario.perfil },
  });
}));

module.exports = router;
