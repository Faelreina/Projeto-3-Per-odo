const router = require('express').Router();
const db = require('../db');
const asyncHandler = require('../utils/asyncHandler');
const { HttpError } = require('../utils/httpError');
const { auth } = require('../middlewares/auth');
const v = require('../utils/validar');

router.use(auth); // tudo aqui exige login

// Minhas consultas
router.get('/', asyncHandler(async (req, res) => {
  const [rows] = await db.execute(
    `SELECT c.id, c.data_hora, c.status, m.nome AS medico, m.especialidade
     FROM consultas c
     JOIN medicos m ON m.id = c.medico_id
     WHERE c.usuario_id = ?
     ORDER BY c.data_hora`,
    [req.usuario.id]
  );
  res.json(rows);
}));

// Agendar
router.post('/', asyncHandler(async (req, res) => {
  const body = req.body || {};
  const medicoId = v.id(body.medico_id, 'medico_id');
  const dataHora = v.dataHoraFutura(body.data_hora);

  try {
    // O banco garante que o mesmo médico não tenha 2 consultas ativas no mesmo horário
    // (índice único), mesmo se duas pessoas tentarem ao mesmo tempo.
    const [r] = await db.execute(
      'INSERT INTO consultas (usuario_id, medico_id, data_hora) VALUES (?, ?, ?)',
      [req.usuario.id, medicoId, dataHora]
    );
    res.status(201).json({ id: r.insertId, medico_id: medicoId, data_hora: dataHora, status: 'agendada' });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'Horário indisponível para este médico');
    if (e.code === 'ER_NO_REFERENCED_ROW_2') throw new HttpError(404, 'Médico não encontrado');
    throw e;
  }
}));

// Cancelar (só a própria consulta)
router.patch('/:id/cancelar', asyncHandler(async (req, res) => {
  const id = v.id(req.params.id);
  const [r] = await db.execute(
    `UPDATE consultas SET status = 'cancelada'
     WHERE id = ? AND usuario_id = ? AND status = 'agendada'`,
    [id, req.usuario.id]
  );
  if (!r.affectedRows) {
    throw new HttpError(404, 'Consulta não encontrada ou já cancelada');
  }
  res.json({ ok: true });
}));

module.exports = router;
