const jwt = require('jsonwebtoken');
const env = require('../config/env');
const { HttpError } = require('../utils/httpError');

function auth(req, res, next) {
  const [tipo, token] = (req.headers.authorization || '').split(' ');
  if (tipo !== 'Bearer' || !token) {
    return next(new HttpError(401, 'Token ausente'));
  }
  try {
    req.usuario = jwt.verify(token, env.JWT_SECRET);
    next();
  } catch {
    next(new HttpError(401, 'Token inválido ou expirado'));
  }
}

function apenasAdmin(req, res, next) {
  if (!req.usuario || req.usuario.perfil !== 'admin') {
    return next(new HttpError(403, 'Acesso restrito a administradores'));
  }
  next();
}

module.exports = { auth, apenasAdmin };
