const { HttpError } = require('../utils/httpError');

function naoEncontrado(req, res) {
  res.status(404).json({ erro: 'Rota não encontrada' });
}

// Precisa ter 4 parâmetros para o Express reconhecer como tratador de erro
// eslint-disable-next-line no-unused-vars
function tratarErros(err, req, res, next) {
  if (err instanceof HttpError) {
    return res.status(err.status).json({ erro: err.message });
  }
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ erro: 'JSON inválido no corpo da requisição' });
  }
  console.error(err);
  res.status(500).json({ erro: 'Erro interno do servidor' });
}

module.exports = { naoEncontrado, tratarErros };
