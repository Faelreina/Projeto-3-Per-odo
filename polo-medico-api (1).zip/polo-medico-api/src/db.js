// Conexão com o MySQL. O banco fica separado (veja a pasta /database).
const mysql = require('mysql2/promise');
const env = require('./config/env');

const pool = mysql.createPool({
  host: env.DB_HOST,
  port: env.DB_PORT,
  user: env.DB_USER,
  password: env.DB_PASS,
  database: env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 5, // baixo, por causa do serverless
  queueLimit: 0,
  timezone: 'Z',      // tudo em UTC
  dateStrings: true,  // datas voltam como texto, sem surpresas de fuso
  ssl: env.DB_SSL ? { rejectUnauthorized: false } : undefined,
});

module.exports = pool;
