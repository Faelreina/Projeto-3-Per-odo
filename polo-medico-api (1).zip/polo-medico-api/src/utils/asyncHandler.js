// Express 4 não captura erros de funções async sozinho.
// Sem isso, qualquer erro no banco derruba a requisição sem resposta.
module.exports = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);
