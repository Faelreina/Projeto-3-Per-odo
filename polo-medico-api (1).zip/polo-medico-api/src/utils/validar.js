const { HttpError } = require('./httpError');

function texto(valor, campo, { min = 1, max = 255 } = {}) {
  if (typeof valor !== 'string' || valor.trim() === '') {
    throw new HttpError(400, `Campo "${campo}" é obrigatório`);
  }
  const limpo = valor.trim();
  if (limpo.length < min) {
    throw new HttpError(400, `Campo "${campo}" deve ter no mínimo ${min} caracteres`);
  }
  if (limpo.length > max) {
    throw new HttpError(400, `Campo "${campo}" deve ter no máximo ${max} caracteres`);
  }
  return limpo;
}

function email(valor) {
  const limpo = texto(valor, 'email', { max: 120 }).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(limpo)) {
    throw new HttpError(400, 'E-mail inválido');
  }
  return limpo;
}

function senha(valor) {
  // não usa trim: espaços podem fazer parte da senha
  if (typeof valor !== 'string' || valor.length < 6) {
    throw new HttpError(400, 'Campo "senha" deve ter no mínimo 6 caracteres');
  }
  if (valor.length > 72) {
    throw new HttpError(400, 'Campo "senha" deve ter no máximo 72 caracteres');
  }
  return valor;
}

function id(valor, campo = 'id') {
  const numero = Number(valor);
  if (!Number.isInteger(numero) || numero <= 0) {
    throw new HttpError(400, `Campo "${campo}" inválido`);
  }
  return numero;
}

// Aceita ISO (ex: 2026-10-20T14:30:00Z) e devolve 'YYYY-MM-DD HH:MM:SS' em UTC,
// que é o formato que o DATETIME do MySQL aceita sem reclamar.
function dataHoraFutura(valor) {
  const data = typeof valor === 'string' ? new Date(valor) : null;
  if (!data || Number.isNaN(data.getTime())) {
    throw new HttpError(400, 'Campo "data_hora" inválido. Use o formato 2026-10-20T14:30:00Z');
  }
  if (data.getTime() <= Date.now()) {
    throw new HttpError(400, 'A data da consulta precisa ser no futuro');
  }
  return data.toISOString().slice(0, 19).replace('T', ' ');
}

module.exports = { texto, email, senha, id, dataHoraFutura };
