// Servidor local (npm run dev). Na Vercel quem manda é o api/index.js
const env = require('./config/env');
const app = require('./app');

app.listen(env.PORT, () => {
  console.log(`API rodando em http://localhost:${env.PORT}`);
});
