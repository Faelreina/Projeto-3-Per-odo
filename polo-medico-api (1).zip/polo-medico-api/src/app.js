const express = require('express');
const cors = require('cors');
const db = require('./db');
const asyncHandler = require('./utils/asyncHandler');
const { naoEncontrado, tratarErros } = require('./middlewares/errorHandler');

const app = express();
app.use(cors());
app.use(express.json({ limit: '100kb' }));

app.get('/', (req, res) => res.json({ status: 'API Polo Médico no ar' }));

// Teste rápido de conexão com o banco: GET /saude
app.get('/saude', asyncHandler(async (req, res) => {
  try {
    await db.query('SELECT 1');
    res.json({ status: 'ok', banco: 'conectado' });
  } catch (e) {
    res.status(503).json({ status: 'erro', banco: 'falhou', codigo: e.code });
  }
}));

app.use('/auth', require('./routes/auth'));
app.use('/medicos', require('./routes/medicos'));
app.use('/consultas', require('./routes/consultas'));

app.use(naoEncontrado);
app.use(tratarErros);

module.exports = app;
