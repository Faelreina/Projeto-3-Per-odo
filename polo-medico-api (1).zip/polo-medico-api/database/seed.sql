-- Dados de exemplo. INSERT IGNORE permite rodar mais de uma vez sem erro de CRM duplicado.
INSERT IGNORE INTO medicos (nome, especialidade, crm) VALUES
  ('Dra. Ana Souza', 'Cardiologia', 'CRM-PE 11111'),
  ('Dr. Carlos Lima', 'Clínica Geral', 'CRM-PE 22222'),
  ('Dra. Marina Alves', 'Pediatria', 'CRM-PE 33333');
