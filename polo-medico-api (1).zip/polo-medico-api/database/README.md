# Banco de dados (MySQL 8)

Pasta independente da API. O MySQL **não roda na Vercel**: em produção use um serviço
externo (Railway, Aiven, Clever Cloud...) e rode os scripts lá.

- `schema.sql`: tabelas (usuarios, medicos, consultas)
- `seed.sql`: médicos de exemplo
- `docker-compose.yml`: MySQL local para desenvolvimento

## Local com Docker
```bash
cd database
docker compose up -d
```
O Docker já cria o banco `polo_medico` e roda os dois scripts sozinho.
No `.env` da API: `DB_HOST=localhost`, `DB_USER=root`, `DB_PASS=root`, `DB_NAME=polo_medico`.

## Em um MySQL que você já tem (nuvem ou local)
Informe o **nome do banco** no comando:
```bash
mysql -h HOST -P PORTA -u USUARIO -p NOME_DO_BANCO < schema.sql
mysql -h HOST -P PORTA -u USUARIO -p NOME_DO_BANCO < seed.sql
```
Use o mesmo `NOME_DO_BANCO` no `DB_NAME` do `.env`.

## Se mudar a tabela depois
Em desenvolvimento, apague o volume (`docker compose down -v`) e suba de novo.
