-- Não cria nem seleciona o banco de propósito:
-- bancos na nuvem já vêm com um banco pronto e não deixam usar CREATE DATABASE.
-- Rode apontando para o banco certo (veja o README desta pasta).

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  perfil ENUM('paciente','admin') NOT NULL DEFAULT 'paciente',
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS medicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  especialidade VARCHAR(80) NOT NULL,
  crm VARCHAR(20) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS consultas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  medico_id INT NOT NULL,
  data_hora DATETIME NOT NULL,
  status ENUM('agendada','cancelada','realizada') NOT NULL DEFAULT 'agendada',
  -- vale 1 só quando agendada; NULL nas outras (NULL não conflita em índice único)
  slot_ativo TINYINT GENERATED ALWAYS AS (CASE WHEN status = 'agendada' THEN 1 ELSE NULL END) STORED,
  UNIQUE KEY uq_medico_horario_ativo (medico_id, data_hora, slot_ativo),
  CONSTRAINT fk_consulta_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  CONSTRAINT fk_consulta_medico FOREIGN KEY (medico_id) REFERENCES medicos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
