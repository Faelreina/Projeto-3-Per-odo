# Polo Médico API

Back end (Node.js + Express + MySQL) para o site e o app mobile do Polo Médico.

## Estrutura
- `src/`: API (rotas, validação, autenticação, tratamento de erros)
- `api/index.js`: entrada para o deploy na Vercel
- `database/`: scripts e docker do MySQL (separado da API)
- `scripts/criar-admin.js`: cria o primeiro administrador

## Rodar local (passo a passo)
```bash
# 1. banco
cd database && docker compose up -d && cd ..

# 2. API
cp .env.example .env          # confira os valores
npm install
npm run dev
```
Teste: abra http://localhost:3000/saude. Deve responder `{"status":"ok","banco":"conectado"}`.

## Criar o primeiro admin
```bash
npm run criar-admin -- "Seu Nome" admin@exemplo.com suasenha123
```

## Rotas
| Método | Rota | Acesso | Descrição |
|---|---|---|---|
| GET | /saude | público | Testa a conexão com o banco |
| POST | /auth/registro | público | Cadastrar paciente |
| POST | /auth/login | público | Login (retorna JWT) |
| GET | /medicos | público | Listar (?especialidade=) |
| GET | /medicos/:id | público | Detalhe |
| POST | /medicos | admin | Cadastrar médico |
| PUT | /medicos/:id | admin | Atualizar médico |
| DELETE | /medicos/:id | admin | Remover médico |
| GET | /consultas | logado | Minhas consultas |
| POST | /consultas | logado | Agendar |
| PATCH | /consultas/:id/cancelar | logado | Cancelar |

Rotas protegidas usam o header `Authorization: Bearer SEU_TOKEN`.

Exemplo de agendamento (`data_hora` em ISO com `Z`):
```json
{ "medico_id": 1, "data_hora": "2026-10-20T14:30:00Z" }
```

## Deploy (Vercel)
1. Hospede o MySQL em um serviço externo e rode `database/schema.sql` nele.
2. Na Vercel, cadastre as variáveis do `.env.example` (com `DB_SSL=true` se o banco exigir SSL).
3. Rode `vercel` na raiz do projeto e teste `/saude` na URL gerada.
